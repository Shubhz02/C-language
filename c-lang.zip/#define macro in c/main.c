/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// #define #undef macro 
#include <stdio.h>
#define A 10
#define PI 3.14159
#define MUL(a,b)a*b

#define MAX(a,b) if(a>b)\
                    printf("\na is maximum"); \
                    else\
                    printf("\nb is maximum");
int main()
{
    int x=A;
    int r=5;
    printf("value of X %d",x);
    printf("\narea of circle is =%f",PI*r*r);
    
    
    printf("\nmultification is %d",MUL(5,2));
    
    printf("\nmultiplication 2 %d",MUL(5-2,7+4));
    
    MAX(3,4);
    
    MAX(5,4);
    //undef MAX  
    return 0;
}
