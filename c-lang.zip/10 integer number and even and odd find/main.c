/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
////WAP to read an array of 10 integers and count total no of even and odd elements ///

#include <stdio.h>
void main()
{
    int i, a[10];
    int even=0, odd=0;
    
    printf("enter 10 integer numbers ");
    
    for(i=0;i<10;i++)
    {
        scanf("%d\n",&a[i]);
        
    }
for(i=0;i<10;i++)
{
    if (a[i]%2==0)
        even = even+1;
    else
        odd=odd+1;
        
}
printf("total even number are %d",even);
printf("\ntotal odd numbers are %d",odd);
}
