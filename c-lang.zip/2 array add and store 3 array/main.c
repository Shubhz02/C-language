/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//two array with size of 5 and sum of those array and store in third array 

#include <stdio.h>

void main()
{
    int i;
    int arr1[5],arr2[5], sumarr[5];
    
printf("enter first array");
for(i=0;i<5;i++)
    scanf("%d",&arr1[i]);
    
printf("\n enter second array");
for (i=0;i<5;i++)
    scanf("%d",&arr2[i]);
    
for(i=0;i<5;i++)
{
    sumarr[i]=arr1[i]+arr2[i];
    
    
printf("\n third array element index %d is = %d",i,sumarr[i]);

}
}
