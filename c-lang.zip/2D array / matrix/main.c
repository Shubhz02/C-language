/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// print 2-d array 
#include <stdio.h>

void main()
{
    int i,j,sum=0;
    int a[2][3];
    printf("enter elements of 2D array ");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        {
        scanf("%d",a[i][j]);
            
        }
        
    }
    printf("matrix is \n");
    for (i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
    {
        printf("%d\t",a[i][j]);
        sum=sum+a[i][j];
        
    }
    printf("\n");
    
}
printf("\nsum=%d",sum);
}
