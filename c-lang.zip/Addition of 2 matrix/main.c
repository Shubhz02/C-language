/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//addition of two matrix 

#include <stdio.h>

int main()
{
 int a[2][3],b[2][3],c[2][3],i,j;
 
 printf("enter a A matrix is \n");
 for(i=0;i<2;i++)
 {
     for(j=0;j<3;j++)
     {
         scanf("%d",&a[i][j]);
     }
 }
 printf("enter B matrix is \n");
 for(i=0;i<2;i++){
     for(j=0;j<3;j++)
     {
         scanf("%d",&b[i][j]);
         
     }
    
 }
// printing matrix 
printf(" matrix is  a\n");
for(i=0;i<2;i++)
{
    for(j=0;j<3;j++)
    {
        printf("%d \t",a[i][j]);
    }printf("\n");
    
}
printf("matrix is b\n");
  for(i=0;i<2;i++) 
  {
      for(j=0;j<3;j++)
      {
          printf("%d \t",b[i][j]);
          
      }printf("\n");
  }
  
  //addition of A&B matrix and store in C matrix
printf("the sum of matrix is \n")  ;
for(i=0;i<2;i++)
{
    for(j=0;j<3;j++)
    {
        c[i][j]=a[i][j]+b[i][j];
        printf("%d\t",c[i][j]); 
        
    }printf("\n");
}
//substraction of A&B matrix and store in C matrix
printf("the sub of matrix is \n")  ;
for(i=0;i<2;i++)
{
    for(j=0;j<3;j++)
    {
        c[i][j]=a[i][j]-b[i][j];
        printf("%d\t",c[i][j]); 
        
    }printf("\n");
}
    
    

}
