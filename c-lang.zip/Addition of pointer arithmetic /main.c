/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//pointer arthimetic addition 

#include <stdio.h>

void main()
{
    int a[5]={1,4,2,-8,0};
    int *p=&a[0];
    int *q=&a[0];
    p=p+1;
    *p=34;
    
    
printf("value is %d\n",*p);
printf("address of element is %d\n",p);
p=p+2;
printf("value is %d\n",*p);

printf("address of element is %d\n",p);

 
}