/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//append mode in file handling 


#include <stdio.h>
#include <stdlib.h>
void main()
{
    FILE *fp=NULL;
    
    char str[30];
    
    fp=fopen("abc.txt","a");
    
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    }
    
    printf("enter the contain you want to append");
    gets(str);  //scanning str data
    
    fputs(str,fp);  
    
    fprintf(fp,"\n%s",str);  //file pointer , data type , string name
    printf("done");
    
    fclose(fp);  //close the file
    
    
}
