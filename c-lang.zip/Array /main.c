/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int a[5];
    int i;
    printf("enter the array elements");
    for(i=0;i<5;i++)
   {
       scanf("%d\n",&a[i]);
    
   }
    
    for(i=0;i<5;i++)   //for forward  output
    
        printf("\narray elements index %d is :%d", i, a[i]);
        
        printf("\n\n");
    for(i=4;i>=0;i--)  //for reversed order output print
    {
        printf("\narray elements index %d is :%d", i, a[i]);
    }
}
