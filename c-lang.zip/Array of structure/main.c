/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// array of structure

#include <stdio.h>
struct student
{
    int rollno;
    char name[20];
    float marks;
};   // end of structure aslway ;after } .


void main()
{
    int i;
    struct student s[3]; // 3 student data via using array
    
    printf("enter stuents rollno , name, marks");
    for(i=0;i<3;i++)
    {
        scanf("%d %s %f",&s[i].rollno,s[i].name,&s[i].marks);
        
    }
    for(i=0;i<3;i++)
    {
        printf("\n %d %s %f",s[i].rollno,s[i].name,s[i].marks);
    }

    printf("\nits done");

    
}
