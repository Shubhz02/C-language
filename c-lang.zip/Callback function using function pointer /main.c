/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//callback function using function pointer in callback

#include <stdio.h>
//sum function
void sum(int a,int b)
{
    printf("sum=%d\n",a+b);
}

//sub function

void sub(int a, int b)
{
    printf("sub=%d\n",a-b);
}

//display function

void display(void (*fptr)(int ,int))
{
    fptr(5,1);

}
// main function calling function 
//callback function like calling function and then passing another function 

void main()
{
    display(sum); // direct to display function and complete and go sum function thne 
    display(sub); // first go to display function after excuting then sub function and done
}
