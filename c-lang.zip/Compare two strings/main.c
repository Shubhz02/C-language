/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//compare two strings 
#include <stdio.h>
#include<string.h>


void main()
{
    int value=0; // variable 
    
    int i,flag=0; // without using function used variables 
    
    
    char s1[30],s2[30];
// printing and scan strings input from user     
    printf("enter string 1 \n ");
    gets(s1);

    printf("enter string 2\n");
    gets(s2);
    
    
// with string compare function strcmp 
    value=strcmp(s1,s2);
    if(value==0)
{    printf("same");
printf("\n");
    
}
else{
    printf("not same");
}


//without string compare function 
for(i=0;s1[i]!='\0' || s2[i]!='\0';i++)
{
    if(s1[i]!=s2[i])
    {
        flag=1;
        break;
       
    }
}
if (flag==1)
{
    printf("not same\n");
}else
{
 printf("\nis same");   
}




















}