/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// concatenate of two strings 
#include <stdio.h>
#include<string.h>

int main()
{
    int len1,len2,i; // for without using function
    char s1[30]="shubham";
    char s2[]="shastri";
    
    
    
    //with strcat function
//strcat(s1,s2); // S1 destination and S2 source

strcat(s1,s2,3); // S1 destination , S2 source of 5 location (many arguments)
printf("string after concatenate is :%s\n",s1);
puts(s2);

/*

  // without using function
len1=strlen(s1);
len2=strlen(s2);
for(i=0;i<=len2;i++)
{ 
    s1[len1+i]=s2[i];
    
}

printf("strings are %s \n",s1);
puts(s2);
*/
}