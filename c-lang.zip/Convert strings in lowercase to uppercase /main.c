/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//convert strings in lowercase into uppercase 

#include <stdio.h>
#include <string.h>


void main()
{
    int i;
    char s1[30];
    printf("enter a string ");
    //gets(s1);
    scanf("%s",s1);
    
  //with funcrion   
   // strlwr (s1);
    
//without function
for(i=0;s1[i]!='\0';i++)
{
    if(s1[i]>='A' && s1[i]<='Z')
    {
        s1[i]=s1[i]+32;
        
    }
}
    printf("%s",s1);

    
}