/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Copy content of one file into another file

#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *fptr1 ,*fptr2;
    char c;
    int n=1;
    
fptr1=fopen("abc.txt","r"); //read 
if(fptr1==NULL)
{
    printf("error");
    exit(1);
}

fptr2=fopen("destination.txt","w");
if(fptr2==NULL)
{
    printf("errorr");
    exit(1);
}    
//for(c=fgetc(fptr1);c!=EOF;c=fgetc(fptr1))

while((c=fgetc(fptr1))!=EOF)
{
    fputc(c,fptr2);  //write data fptr2
}

    fclose(fptr1);
    fclose(fptr2);
    printf("its done");
}
