/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// c program to count no of lines in a text file 

#include <stdio.h>
#include <stdlib.h>
void main()
{
    FILE *fp=NULL;  
    
    int count=1;
    char ch;
    
    fp=fopen("abc.txt","r"); //read mode
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    }
//for(c=fgetc(fp);c!=EOF;c=fgetc(fp))

while((ch=fgetc(fp))!=EOF)
{
    if(ch=='\n')
    {
        count++;
        
    }
}
fclose(fp);
printf("lines are %d\n",count);
}
