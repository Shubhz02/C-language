/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Dangling pointer in Compile

#include <stdio.h>
#include <stdlib.h>  //malloc function
int* f()
{
    int a=9;
    return &a;
    
}
void  main()
{
    int *ptr=NULL;  //f();
    {
        int a=5;
        ptr=&a;
        printf("%d\n",*ptr);
    }
    
    
    /*int *ptr=(int*)malloc(sizeof(int));
    *ptr=10;
    printf("%d\n",*ptr);
    
    free(ptr); //free memory
    ptr=NULL; 
    printf("%d\n",*ptr);
    */
    
    
    printf("%d\n",*ptr);
    

}