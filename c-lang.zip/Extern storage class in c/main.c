/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// extern storage classes 
#include <stdio.h>

void fun1();  //function decleration
void fun2();


void main()
{
    extern int x;  //extern (allready decleared int x value tell to compiler)
    
    printf("x=%d",x);  //x=10
    fun1();  //calling function fun1
    fun2(); // calling function fun2

}

void fun1()  //function called 1
{
    int x=1;
    x+=5;  //x=x+5;
    printf("\n x=%d",x);
}

void fun2()  //function called 2
{
    int y=4;
    y++;
    printf("\ny= %d",y);
}

int x=10; //global varible ...(acess to extern)
