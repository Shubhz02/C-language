/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//File handling in Compile (Writing)

#include <stdio.h>
#include<stdlib.h>
#include<string.h>

void main()
{
    FILE *fp=NULL;//ceate file fp
    int i;
    
   char ch='a'; 
    char str[20];

    fp=fopen("abc.txt","w");  // open function abc.txt file and write mode and save to fp
    
    
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    }
    
    
    printf("enter the string\n");
    gets(str);
    
    for(i=0;i!=strlen(str);i++)
    fputs (str[i],fp);
    fputc(ch,fp);
    fclose(fp); //close file (name)
}
