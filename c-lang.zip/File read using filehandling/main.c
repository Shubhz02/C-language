/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// read from file ...file handling

#include <stdio.h>
#include <stdlib.h>


 void main()
{
    
    FILE *fp=NULL;
    char ch; //character
    
    
    char str[25];  //string
    
    fp=fopen("abc.txt","r");    // open file (file name )(read mode)

if(fp==NULL)  //check condition 
{
    printf("error");
    exit(1);
}
//for character

while(!feof(fp))
{
    ch=fgetc(fp);  //character 
    printf("%c",ch);
    
}
    
// for string 
while(!feof(fp)) //new line operator full print file data
{
    fgets(str,5,fp);  // string name , size of lenght and file name
    printf("%s",str);
}
    
    fclose(fp); // close the file
    
}
