/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//find length of string

#include <stdio.h>
#include<string.h>   // string 

void  main()
{
    int count=0, i=0;
                       // string initialization 
 char name[30];
                      //input from user 
 printf("enter name :\n");
gets(name);  // scaning data 

// with string length funcrion find length 
 count=strlen(name);// internal pointer
 
 puts(name); // printing string 
 printf("string length is %d",count);
 
printf("\n");
// without using string length fuction fiding length

while(name[i]!='\0')
{
    count ++;
    i ++ ;
    
}

printf("string length is %d",count);

    
}