/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*****************************************************************/


//DYanamic Memory Allocation using free () function

#include <stdio.h>
#include <stdlib.h>

int *display()
{
    int n,i,*ptr;
    
    ptr=(int*)malloc(3*sizeof(int));
    
    printf("\n enter the values");
    for(i=0;i<3;i++)
    {
        scanf("%d",(ptr+i));
    }
    return ptr;
}


int main()
{
    int n,i,*ptr1;
    
    /*printf("enter total number of values");
    scanf("%d",&n);
    
    ptr=(int*)malloc(n*sizeof(int));//malloc function
    if(ptr==NULL)
    {
        printf("error");
    }
    
    printf("\nenter the values");
    for(i=0;i<n;i++)
{
    scanf("%d",(ptr+i));
}
*/
ptr1=display();
//free(ptr); //free function used

printf("\n the entered values are");
for(i=0;i<n;i++)
{
    printf("%d\t",*(ptr1+i));
}

    free(ptr1);
}
