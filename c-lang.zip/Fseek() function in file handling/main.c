/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// fseek() function in file handling


#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *fp=NULL ;
    char ch;
    //char str[20];
    fp=fopen("abc.txt","r");  //file name + (read) mode 
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    
    }
    fputs("shuham",fp);  //string print 
    
    fseek(fp,4,SEEK_SET); //beginning postion set of 3 offset
    ch=fgetc(fp);
    printf("%c",ch);
    
    fseek(fp,-2,SEEK_CUR); //cursur at postion set of -2 offset 
    ch=fgetc(fp);
    printf("%c",ch);
    
    fseek(fp,4,SEEK_END); //ENDING  postion set of 4 offset
    ch=fgetc(fp);
    printf("%c",ch);
    
    //fputs("shubham",fp); //string
    
    fclose(fp);
}