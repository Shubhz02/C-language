/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//ftell() function in file handling

#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *fp=NULL;
    char ch;
    char str[50];
    
    fp=fopen("abc.txt","r");  //read function
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    }
printf("%d",ftell(fp));  //file pointer location 
//ch= fgetc(fp);
fscanf(fp,"%s",str);
printf("%s",str);

fseek(fp,0,SEEK_END);

print("\n%d",ftell(fp));




fclose(fp);    
}
