/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


void sum()   ///declaration of sum function
{
    int a,b,sum=0;
    printf("enter the numbers");
    scanf("%d %d",&a,&b);
    
    sum=a+b;
    printf("sum=%d\n",sum);
    //printf("\n");
}
void sub()  // declearation for substraction function
{
    int a,b,sub=0;
    printf("enter the number to substraction ");
    scanf("%d %d",&a,&b);
    
    sub=a-b;
    printf("sub=%d\n",sub);
    sum();   // any function used calling function 
}

void main ()  
{
    sum();  // calling sum function 
    printf("its working\n");
    sub(); // calling sum function
    printf("its done\n");
    
}