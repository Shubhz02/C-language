/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//function type - 2)No argument with return type  

#include <stdio.h>
//declration 
int sum (void);  // datatype(int) functionName(sum) argument(no ...void)

void main()  //calling function
{
    int s;
    s=sum();  // sum function value store in s variable
    printf("sum=%d\n",s);
    printf("its done\n");
}

int sum()  // called function
{
    int a,b,sum=0;
    printf("enter the numbers");
    scanf("%d %d",&a,&b);
    sum=a+b;
    return (sum);  // return the sum function (with return type )

    // return a+b;
    
}  // all type of data with all type of logic used for practice