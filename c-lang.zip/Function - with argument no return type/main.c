/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// function type - 3) with argument without return type 

#include <stdio.h>

int sum (int,int);  // datatype functionName Argument(datatype)

void main()   // calling function
{
    int a,b,c;
    printf("enter the numbers");
    scanf("%d %d",&a,&b);
    
    c=sum(a,b);  // calling sum function  
    
    printf("sum=%d\n", c);   // retun the sum function and print output

    printf("its done");
    
}

int sum(int x, int y)
{
    //int sum=0;
    //sum=x+y;
    
    return x+y;
    
}