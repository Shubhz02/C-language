/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void sum();  // function declaration 
//data_type function_name (arguments)
char fun(); // declration 

void main()
{
    //sum(); // function calling (data , data)
char ch;
ch = fun();
printf("ch=%c\n",ch);


    printf("its done");
    
}


char fun()
{
    char c;
    printf("enter a character");
    scanf("%c",&c);
    return c;
}
void sum(void)  //defination of function 
{
    int a,b,sum=0;
    printf("enter two numbers");
    scanf("%d %d",&a,&b);
    sum=a+b;
    
    printf("sum=%d\n",sum);
    
}
