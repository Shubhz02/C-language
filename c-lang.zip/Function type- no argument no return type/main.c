/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// function types - 1)No arguments no return type 

#include <stdio.h>

// declration of function
void sum(void); // void no type 

void main()  // calling function 
{
    sum();  // calling sum function 
    //first go function 
    printf("its done");  // after retunning sum function then exist.
}

void sum()   // called function
{
    int a=5,b=8;
    int sum=0;
    
    sum= a+b;
    printf("sum=%d\n",sum);
 // go to main function    
}
