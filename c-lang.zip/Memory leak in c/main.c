/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// memory leak in Compile

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ch=1;
    int *ptr;
    while(ch<50)
    {
        printf("memory leak\n");
        ptr=(int*)malloc(40000*sizeof(int));
        
        printf("continue?? press 1 for continue");
        scanf("%d",&ch);
    
//memory leak solution
free(ptr);

}
}
