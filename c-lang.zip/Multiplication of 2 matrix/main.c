/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//print multiplication of 2 matrix 
#include <stdio.h>
#define N 50 // size of array using macro 


int main()
{
    int a[N][N], b[N][N], c[N][N],i,j,k,sum,m,n,p,q;
    printf("enter rows and colums for first matrix\n");
    scanf("%d %d ",&m,&n);
    printf("enter first matrix\n ");
    
    for(i=0;i<m;i++){
        for(j=0;j<n;j++)  //n is number of col
        {
            scanf("%d",&a[i][j]);
            
        }
    } 
    
    printf("enter rows and colums for second matrix \n");
    
    scanf("%d %d ",&p,&q);
    printf("enter second matrix\n ");
    
    for(i=0;i<p;i++)
    {
        for(j=0;j<q;j++)
        {
            scanf("%d",&b[i][j]);
            
        }
    } 
    
    // printing matrix 
    printf("\nfirst matrix\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d\t",a[i][j]);
            
        }
        printf("\n");
    }
    printf("\nsecond matrix \n");
    for(i=0;i<p;i++)
    {
        for(j=0;j<q;j++)
        {
            printf("%d\t",b[i][j]);
        }
    }printf("\n");
    
    //first check if multiplication is done or not (no of 1 st matrix col =row to 2nd matrix equal)
    if (n!=p) // number of col not equal = numbers of rows
    {
        printf ("can not multiply");
        
    }else
    {
        for(i=0;i<m;i++) //resultance matrix size is m*q 
        {
            for(j=0;j<q;j++)
            { sum=0;
                for(k=0;k<m;k++) 
                {
                    sum=sum+(a[i][k]*b[k][j]);
                
                }
                c[i][j]=sum;
                
               // scanf("%d"&a[i][j]);
            }
        }
        printf("\nmultiplication is ");// prinnt 
        for(i=0;i<m;i++)
        {
            for(j=0;j<q;j++)
            {
                printf("%d\t",c[i][j]);
            }
    
        printf("\n");
        }
    }
}
