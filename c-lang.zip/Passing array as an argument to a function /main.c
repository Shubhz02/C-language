/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//passing array as an argument to a function in c 
#include <stdio.h>

int avg(int[],int);// declaration    

void main()   // calling 
{
    int average,size; 
    int marks[5]={10,20,30,40,50};
    size=sizeof(marks)/sizeof(marks[0]);//sizeof is operator used 
    average=avg(marks,size); 
    
    printf("average=%d\n",average);
    printf("inside main size of array is (in byte) %d\n",sizeof(marks));
}


int avg(int marks1[],int size)//called
{
    int i,sum,average;
    for(i=0;i<size;i++)
    {
        sum=sum+marks1[i];
    }
    average=sum/size;
    printf("inside of avg function size of array is (in bytes ) %d\n",sizeof(marks1));
    return average;
}