/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//passing string as an argument to a function 

#include <stdio.h>
void display(char[],char[]); // declration 

void main() // calling
{
 char str1[]={"shubham"};
 char str2[]={"shastri"};
 
 display(str1,str2);
 
    printf("its done");

}

void display (char str[],char str[])  // called 
{
    int i,len;
    for(i=0;str1[i]!='\0';i++)
    {
        len=len+1;
    }
str2[1]='AM';

printf("length of string 1 is %d\n",len);
printf("both the string are %s %s",str1,str2);

    
}