/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// pointer program

#include <stdio.h>

void main()
{
    int a[]={10,11,01,56,67,5,4};
    
    int *p,*q;
    p=a;
    
    printf("%d\n",*p);
    printf("%d %d %D \n ", (*p)++,*p++,*++p);
    
    q=p+3;
    
    printf("%d\n",*q-3);
    printf("%d\n",*--p+5);
    printf("%d\n",*p+*q);
    
}