/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// pointer to pointer (double pointer)

#include <stdio.h>

void main()
{
int a=10;
int *p=&a;
int **q=&p;
int ***r=&q;
/*
*p=12;
**q=17;
*/

printf("a=%d\n",a);
printf("a=%d\n",*p);
printf("a=%d\n",*(*q));
printf("a=%d\n",*(*(*r)));


printf("address of q=%x %x\n",r,&a);
printf("address of p=%x %x\n",&p,q);

}
