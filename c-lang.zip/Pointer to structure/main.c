/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Pointer to structure

#include <stdio.h>

struct student
{
    int rollno;
    char name[20];
    float marks;
};

void main()
{
    struct student s1={01,"shubham",89.5};
    
    struct student *ptr=&s1;
    
    //printf("enter rollno, name, marks s1");
    scanf("\n%d %s %f",(*ptr).rollno,(*ptr).name,(*ptr).marks);
    
    
    printf("\n %d %s %f",(*ptr).rollno,(*ptr).name,(*ptr).marks);
}
