/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//pre-defined macros in c(conditional cmd)

#include <stdio.h>

int main()
{
    printf("date :%s",__DATE__);
    printf("\n time: %s",__TIME__);
    printf("\nFILE: %s",__FILE__);
    printf("\nline %s",__LINE__);
    printf("\nstdc %s",__STDC__);

    return 0;
}
