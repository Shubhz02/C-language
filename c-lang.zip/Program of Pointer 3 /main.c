/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// pointer program 3 using character string 

#include <stdio.h>

void main()
{ 
    /*//assignment of read only location

 const int a=-11; // removing const then value assigning and a=12 
const int *ptr=&a;// only read 
*ptr=12;
printf("a=%d",a);
} */

char str[]={"shubham shastri"};
    char *ptr=str;
    
    printf("%c\n",*ptr);
    printf("%c\n",*(ptr++ +1));
    printf("%c\n", *((ptr-- +5)-1)+3);
    printf ("%c\n", *(++ptr +10)-32);
    printf("%c %c %c\n ", *ptr,*++ptr ,*--ptr); 
}