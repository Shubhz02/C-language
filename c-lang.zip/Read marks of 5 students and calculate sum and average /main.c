/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


// read marks of 5 students . calculate sum and average using array 
#include <stdio.h>
void main()
{ 
    int i;
    int marks[5];  
    float sum=0, avg ;
    
    printf("enter marks ");
    
    for(i=0;i<5;i++)
    {
        scanf("%d", &marks[i]);
        
    }
    for(i=0;i<5;i++)
    {
        sum=sum+marks[i];
        
    }
    avg=sum/5;  //total divided by total subject count
    printf("sum=%f",sum);
    printf("\navg=%f",avg);
}
