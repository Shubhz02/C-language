/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Register storage class

#include <stdio.h>

int main()
{
    register int i,sum=00; //register 
    //default value is garbage value 
    //register int x;
    for(i=0;i<10;i++)
    {
        sum=sum+i;//block scope
    }
    
    printf("\n%d",sum); //function scope

    return 0;
}

