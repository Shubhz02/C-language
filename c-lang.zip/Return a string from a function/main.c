/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//return a string from a function

#include <stdio.h>
char* display(); // declration


void main()
{
    char* str;
    //const char* str;  //const used and read only 
    str= display();
    
    printf("string is %s\n",str);
    
    str[0]='z';
    
    printf("string is %s\n",str);
    

}
//its is read only memory 
/*
char* display()
{
return "shubham";  // dynamic memory type not erasable while returning main function
    
}
*/


// stack part display function and clear out offunction 

char*display()
{
    static char str[]="shubham";  //static is seperate memory allocation and editable form
    
    //char* str="shubham";  //read only not modify
    return str;
}



// read only type
/*
const char* display()
{
    const char* str="shubham";
    return str;
}
*/


