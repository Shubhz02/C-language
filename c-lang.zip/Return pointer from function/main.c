/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// returning pointer from function
#include <stdio.h>

int* returnpointer(int[]);  // declaration

void main()  
{
    int *p;
    int a[]={1,2,3,4,5};
    p=returnpointer(a); // calling 
    
    printf("d\n",*p);// printing pointer address

}

int* returnpointer (int a[])
{
    a=a+2; // increment of pointer
    return a;
}