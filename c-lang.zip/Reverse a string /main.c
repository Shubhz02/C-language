/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// reversed a string strrev used and without 

#include <stdio.h>
#include<string.h>
void main()
{
    int l,i,j;
    char s1[30],c;

    printf("enter string\n");
    gets(s1);
    l=strlen(s1);   // string length function used 
   /* 
    for(i=0;i<l/2;i++)
    {
        c=s1[i];
        
        s1[i]=s1[l-1-i];
        s1[l-1-i]=s1[i];
        
    }*/
    
    //without 
    for(i=0,j=l-1;i<j;i++,j--)
    {
        c=s1[i];
        s1[i]=s1[j];
        s1[j]=c;
    }
    printf("%s",s1);
    
}





















