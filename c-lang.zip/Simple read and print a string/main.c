/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// program to read and print a string.
#include <stdio.h>

int main()
{
   //char name [30]={"hello"};         //direct print 
    char name [30];
    printf("enter a string:");
    //scanf("%s",name);               //from user and space not read direct stop


  // gets used read data from user
    
    gets(name);// store the complete line beyound allocate memory is buffer overflow promble
    printf("%s",&name (2));  // memory adrress to start printting
    
    printf("%20.2s",name); // output printing directly
    printf("%5s",name);
    // length 
    //using puts for next line 
    puts(name); 
    puts (name);
    
}
