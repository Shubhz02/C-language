/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//static storage class in c

#include <stdio.h>
static char ch;
void display();//function decleration

void main()
{
    display();
    display();  //calling function
    
    printf("\nch %c",ch);
    //printf("x=%d",x);  //undeclration error not acess x
}

void display()  //function called
{
    static int x;  //static storage class
    int y=10;
    x+=10;    //x=x+10  same
    y--;
    printf("\n x=%d",x);
    printf("\n y=%d",y);
}