/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Storage classes in c- Scope type -> 1. program scope  2.blocks scope  3.function scope

#include <stdio.h>
void fun1(); //declearation function

int a=50;   //program scope (global)


int main()
{
       // int a=10;
    fun1(); //function calling
    {
        int a=20;      //Block scope 
        printf("inside the block scope %d",a);
    }
    {
    printf("\n inside block2 %d",a++); //block scope2
    }
    printf("\n inside main %d",a);
    return 0;
    
}

void fun1()    //function scope (function called)
{
    int a=30;
    printf("function scope %d\n",a);
    
}