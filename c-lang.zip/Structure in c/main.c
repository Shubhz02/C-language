/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//structure in c 

#include <stdio.h>

struct student
{
    int rollno;
    char name[30];
    float marks;
    
}s3={06,"akash",89},s4;    // in sturcture after } ; compulsary

void main()
{
    //intialization of sturcture and same datatype as struct called function
    struct student s1={01,"shubham",75};  // 
    struct student s2={05,"jenny",88};
    
    
    printf("enter info for s4");
    scanf("%d %s %f",&s4.rollno,&s4.name,&s4.marks);
    
    //s1=s2;  //s2 all data copie by s1
    
    
    printf("\ninfo for s1");
    printf("\n %d %s %f", s1.rollno,s1.name,s1.marks);
    
    printf("\n info for s2");
    printf("\n %d %s %f", s2.rollno,s2.name,s2.marks);
    
    printf("\ninfo for s3");
    printf("\n %d %s %f",s3.rollno,s3.name,s3.marks);
    
    printf("\n info for s4");
    
    printf("\n %d %s %f", s4.rollno,s4.name,s4.marks);
}