/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[3][3],i,j,sumrow,sumcol;
    
    printf("enter a matrix\n");
    
    for(i=0;i<3;i++) // read the matrix
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
            
        }
    }printf("\n the matrix is :\n");
    
    for(i=0;i<3;i++) // print the matrix
    {
        for(j=0;j<3;j++)
        {
            printf("%d\t",a[i][j]);
            
        }
        printf("\n");
    }
  
    printf("sum of row and column: \n");
    
    for(i=0;i<3;i++)
    {
        sumrow=sumcol=0;
        for(j=0;j<3;j++)
        {
            sumrow=sumrow+a[i][j];
            sumcol=sumcol+a[j][i];
        }
  
    printf("\nsumrow=%d\t,sumcol=%d\t",sumrow,sumcol);
        
    }printf("\n");
    
    
}
