/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//switch case using function pointer 

#include <stdio.h>

void add(int a,int b)
{
    printf("%d",a+b);
}
void sub(int a, int b)
{
    printf("%d",a-b);

}
void mul(int a,int b)
{
    printf("%d",a*b);

}
void div(int a,int b)
{
    printf("%d",a/b);
}


void main()
{
    int ch,a,b;
    void (*fptr[10])(int,int)={add,sub,mul,div};
    printf("enter choice\n");
    scanf("%d",&ch);
    
    printf("enter two numbers\n");
    scanf("%d %d",&a,&b);
    
    
    (*fptr[ch])(a,b) ;; // switch case all replace with this line
}