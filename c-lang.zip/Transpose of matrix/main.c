/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//transpose of matrix 

#include <stdio.h>

int main()
{
    int a[2][3],i,j;
    
    printf("enter element of matrix\n ");
    
    
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);   //for input scanning 
        }
    }
    printf("print of mtrix is \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d\t",a[i][j]);   //for input printing 
        }
        printf("\n");
    }
 printf("\ntranspose of matrix is:\n");
    for(i=0;i<3;i++) //transpose of matrix print 
    {
        for(j=0;j<2;j++)
        {
            printf("%d\t",a[j][i]);
        }
        printf("\n");
    }
    


}