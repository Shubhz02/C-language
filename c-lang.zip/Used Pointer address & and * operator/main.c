/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// pointer & * 
#include <stdio.h>

void main()
{
    int a =10,b=9;
    int *p,*q;
    p=&a;
    q=&b;
    printf("value of a= %d\n",a);
    printf("value of a= %d\n",*p);
    
    printf("address of a= %x\n",&a);
    printf("address of a= %x\n",p);
    printf("address of a= %x\n",&p);

}