/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// void pointer in c 

#include <stdio.h>
void main()
{
    
    void *vp;
    
    int a=5;
    float b=1.56;
    char c='C';
    
    
    vp=&a;
    printf("a=%d\n",*(int*)vp);
    
    
    vp=&b;
    printf("B=%f\n",*(float*)vp);
    
    vp=&c;
    printf("c=%c\n",*(char*)vp);
    
    
}
