/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// a+ mode in file handling


#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *fp=NULL ;
    char ch;
    //char str[20];
    fp=fopen("abc.txt","a+");  //file name + (a+) mode 
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    
    }
    fputs("shuham shastri",fp);
    rewind(fp);
    
    while(!feof(fp))
    {
        ch=fgetc(fp);
        printf("%c",ch);
    }
    //fputs("shubham",fp); //string
    
    fclose(fp);
}