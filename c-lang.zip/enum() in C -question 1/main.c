/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//enum() in c ...question 1


#include <stdio.h>

enum xenum{c,cpp,java};

enum yenum{xneum};

 main()
{
    enum xenum var;
    enum yenum var1;
    
    printf("%d",sizeof(var));
    printf("\n%d",sizeof(var1));
    

    return 0;
}
