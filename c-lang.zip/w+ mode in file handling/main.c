/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// w+ mode in file handling
// writing + read + create new file (not exist)

#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *fp=NULL ;
    
    char str[20];
    fp=fopen("abc.txt","w+");  //file name + (w+) mode 
    if(fp==NULL)
    {
        printf("error");
        exit(1);
    
    }
    
    fputs("shubham",fp); //string
    
    fclose(fp);
}
